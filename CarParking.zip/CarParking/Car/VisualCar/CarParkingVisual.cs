using CarSpace;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisualCar
{
    public partial class CarParkingVisual : Form
    {
        CarList list;
        public CarParkingVisual()
        {
            InitializeComponent();
            list= new CarList();
        }

        private void button1_Click(object sender, EventArgs e) // ce sunt parametrii sender si e?
        {
            if (string.IsNullOrEmpty(textBox1.Text))
                {
                MessageBox.Show("Id cannot be empty!");
                    return;
            }

            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show($"{textBox1.Text} is not a number");
                    return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
                {
                MessageBox.Show("Model cannot be empty!");
                    return;
            }

            if (string.IsNullOrEmpty(textBox3.Text))
                {
                MessageBox.Show("Manufacturer cannot be empty!");
                    return;
            }

            if (string.IsNullOrEmpty(textBox4.Text))
                {
                MessageBox.Show("Engine cannot be empty!");
                    return;
            }

            if (string.IsNullOrEmpty(textBox5.Text))
                {
                MessageBox.Show("Price cannot be empty!");
                    return;
            }

            double price;
            if (!double.TryParse(textBox5.Text, out price))
            {
                MessageBox.Show($"{textBox5.Text} is not a number");
                return;
            }

            if (string.IsNullOrEmpty(textBox6.Text))
                {
                MessageBox.Show("Year cannot be empty!");
                    return;
            }

            int year;
            if (!int.TryParse(textBox6.Text, out year))
            {
                MessageBox.Show($"{textBox6.Text} is not a number");
                return;
            }

            if (string.IsNullOrEmpty(textBox7.Text))
                {
                MessageBox.Show("Color cannot be empty!");
                    return;
            }

            if (string.IsNullOrEmpty(textBox8.Text))
                {
                MessageBox.Show("Fuel cannot be empty!");
                    return;
            }

            Car car = new Car(
                id,
                textBox2.Text,
                textBox3.Text,
                textBox4.Text,
                price,
                year,
                textBox7.Text,
                textBox8.Text
                );

            list.Add(car);

            richTextBox1.Clear();
            richTextBox1.Text = list.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Id cannot be empty!");
                return;
            }

            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show($"{textBox1.Text} is not a number");
                return;
            }

            Car c =list.GetById(id);

            if (c == null)
            {
                MessageBox.Show($"The object with id {id} doesn't exist");
                return;
            }

            list.Remove(c);

            richTextBox1.Clear();
            richTextBox1.Text = list.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            list.Parking.Clear();
            richTextBox1.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            list.SortByYear();
            richTextBox1.Clear();
            richTextBox1.Text = list.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            list.SortByPrice();
            richTextBox1.Clear();
            richTextBox1.Text = list.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}