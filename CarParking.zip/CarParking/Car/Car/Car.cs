using System;

namespace CarSpace
{
    public class Car
    {
        int _id;
        string _model;
        string _manufacturer;
        string _engine;
        double _price;
        int _year;
        string _color;
        string _fuel;

        public Car(int id, string model, string manufacturer, string engine, double price, int year, string color, string fuel)
        {
            _id = id;
            _model = model;
            _manufacturer = manufacturer;
            _engine = engine;
            _price = price;
            _year = year;
            _color = color;
            _fuel = fuel;
        }

        //getters & setters

        public int Id
        { 
          get { return _id; }
          set { _id = value; }

        }

        public string Model
            {
              get { return _model; } 
              set { _model = value; } 
            }

        public String Manufacturer
        {
            get { return _manufacturer; }
            set { _manufacturer = value; }
        }

        public string Engine
        {
            get { return _engine; }
            set { _engine = value; }
        }

        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public string Color
        {
            get { return _color; }
            set { _color = value; }
        }

        public string Fuel
        {
            get { return _fuel; }
            set { _fuel = value; }
        }

        public override string ToString()
        { return $"{Id}; {Model}; {Manufacturer}; {Engine}; {Price}; {Year}; {Color}; {Fuel}"; }

        public override bool Equals(object obj)
        {
            if (!(obj is Car))
            {
                return false;
            }

            Car other = obj as Car; // nu inteleg - as 

            return Id == other.Id &&
                   Model == other.Model &&
                   Manufacturer == other.Manufacturer &&
                   Engine == other.Engine &&
                   Price == other.Price &&
                   Year == other.Year &&
                   Color == other.Color &&
                   Fuel == other.Fuel;
        }
    }
}
