﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarSpace
{
    public class CarList
    {
        public List<Car> Parking { get; private set; } // nu inteleg { get; private set; }

        public CarList()
            {
            Parking = new List<Car>();
            }

        public void Add(Car c)
        {
            if(!Parking.Contains(c))
            {   
                Parking.Add(c);
            }
        }

        public void Remove(Car c)
        {
            if (Parking.Contains(c))
                { Parking.Remove(c); }
        }

        public Car GetById(int id)
        {
            foreach (Car c in Parking)
            {
                if (c.Id == id)
                    return c;
            }

            return null;
        }

        public override string ToString()
        { 
            string res = "";
            foreach (Car c in Parking)
                res=res+c.ToString() + System.Environment.NewLine;

            return res;
        }
        public void SortByYear()
        {
            Parking=Parking.OrderBy(car => car.Year).ToList(); // de unde stie ce tip are car? si dc ii trb functie lambda
        }

        public void SortByPrice()
        {
            Parking=Parking.OrderBy(car => car.Price).ToList();
        }


    }
}
